document.getElementById('floodForm').addEventListener('submit', function(e) {
    e.preventDefault();
  
    const rainfall = parseFloat(document.getElementById('rainfall').value);
    const riverLevel = parseFloat(document.getElementById('riverLevel').value);
    const humidity = parseFloat(document.getElementById('humidity').value);
  
    let result = "";
  
    // Simulated AI logic (replace with backend API call in real system)
    if (rainfall > 250 && riverLevel > 3.5 && humidity > 85) {
      result = "⚠️ Flood Risk Detected!";
      document.getElementById('result').style.color = "red";
    } else {
      result = "✅ No Flood Risk.";
      document.getElementById('result').style.color = "green";
    }
  
    document.getElementById('result').innerText = result;
  });
  